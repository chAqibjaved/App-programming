<?php

$servername = "localhost";     // Change if your DB is on another host
$username = "qkoaawrm_mymed_appuser";   // Replace with your DB username
$password = "jie*p0l2{&t-";   // Replace with your DB password
$database = "qkoaawrm_Mymed";   // Replace with your DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
} else {
    echo "✅ Connected successfully";
}

$conn->close();
?>
