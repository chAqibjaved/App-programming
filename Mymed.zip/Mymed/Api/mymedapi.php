<?php

include('library/crud.php');
include('library/functions.php');
$data = file_get_contents('php://input');
$json_data = json_decode($data , true);
$db = new Database();
$db->connect();
$fn = new Functions();

// Change default timezone to Europe/Berlin
date_default_timezone_set("Europe/Berlin");

// Set database character encoding
$db->sql("SET NAMES 'utf8'");

$response = array();
$access_key = "6808";

/*loginrequest
 	API methods
	------------------------------------

*/


$sqluserquery ="SELECT * from User";

 
 

// // Login User
// if(isset($_GET['access_key']) && isset($_GET['try'])){
	
//         $response['status'] = "false";
// 		$response['message'] = "Invalid Access Key";
// 		echo json_encode($response);
// 		return false;

    
// }

// ///  create new user to the applicaiton 

if(isset($json_data['access_key']) && isset($data) && isset($json_data['insertnewusers'])){
	/* Parameters to be passed
		access_key:6808
		get_categories:1
		id:31 //{optional}
	*/
	if($access_key != $json_data['access_key']){
		$response['status'] = "false";
		$response['message'] = "Invalid Access Key";
		echo json_encode($response);
		return false;
	}

             $name		=$json_data['name'];
			 $dob	=$json_data['dob'];
			 $passportId	=$json_data['passportId'];
			 $disease	=$json_data['disease'];
			 $password	=encryptpassword($json_data['password']);
			 
		     /// check passport Id already register 
			      if(!empty($passportId)){
		                   $sql ="SELECT * FROM `User` WHERE `passportId`='$passportId'";
			                $db->sql($sql);
			                $result = $db->getResult();
			                if (!empty($result)) {
			     
			                $response['status'] = "false";
			               $response['message'] = "User with Same Id already Register";
			                 echo json_encode($response);
			                 return;
			   
		                    }
		          } // end of mobile checking
			       /// inserting data into the database 

			             $data = array(
				        'name'  => $name,
				        'dob'	 => $dob,
				        'passportId'=> $passportId,
				        'disease'=> $disease,
				        'password'=> $password
			            );
                		$sql = $db->insert('User',$data);
                		$res = $db->getResult();
                    		if($sql){
                    		  $response['status'] = "true";
                    		 
                    		     // Return Success - Valid Email
                                $msg = 'Your account has been made.';
                                 $response['message'] = $msg;
                                 $sqluserquery1=$sqluserquery;
                                 $sqluserquery1 .= "WHERE `passportId`='$passportId'";
                                 $db->sql($sqluserquery1);
    			                 $result = $db->getResult(); 
    			                 $response['data'] = $result;
    			                              
                    	    }
                    	    else{
                    	        $response['status'] = "false";
                    		    $response['message'] = $res;
                    	    }        
		    echo json_encode($response);			
}





// ///  Login Request here 

if(isset($_GET['access_key'])  && isset($_GET['loginrequest'])){
	/* Parameters to be passed
		access_key:6808
		get_categories:1
		id:31 //{optional}
	*/

    

	if($access_key != $_GET['access_key']){
		$response['status'] = "false";
		$response['message'] = "Invalid Access Key";
		echo json_encode($response);
		return false;
	}

	$id       = $db->escapeString($_GET['id']);
	$password = $db->escapeString($_GET['password']);
	
	$sql ="SELECT passportId , password FROM User where ( passportId  ='$id') ";
	$db->sql($sql);
	$result = $db->getResult();
	// print_r($result);
	if (!empty($result)) {
	    
	    $hashpassowrd=$result[0]['password'];
	    
	    if (password_verify($password, $hashpassowrd)) {
	        
	          $sqluserquery1=$sqluserquery;
              $sqluserquery1 .= " WHERE ( passportId='$id')";
	        
	      
                                  
                                     $db->sql($sqluserquery1);
        			                 $result = $db->getResult(); 
        			                 $response['data'] = $result;
        			                 $response['status'] = "true";
        			                 $response['message']="data found";
        			                 
          
           
        } 
        else {
            
        $response['status'] = "false";
		$response['message'] = "User id or Password Are Invalid";
        
            
        }
	    
	    
	    
	    
	}
	else{
	    
	    $response['status'] = "false";
		$response['message'] = "You Are Not Register ,Please First SignUp   ".$id;
		
	}
	
	
	
             
		        
		    echo json_encode($response);
			 

}

//// end of login request ////////////////////






///////////////////////// changed password screen ////////////////////////

// if(isset($_GET['access_key']) && isset($_GET['changepasswordtonew'])){
// 	/* Parameters to be passed
// 		access_key:6808
// 		get_categories:1
// 		id:31 //{optional}
// 	*/
// 	if($access_key != $_GET['access_key']){
// 		$response['status'] = "false";
// 		$response['message'] = "Invalid Access Key";
// 		echo json_encode($response);
// 		return false;
// 	}
// 	if(isset($_GET['id'])){
// 		$id = $db->escapeString($_GET['id']);
// 		$changepasswordtonew = $db->escapeString($_GET['changepasswordtonew']);
// 		$password = encryptpassword($db->escapeString($_GET['password']));
// 		$sqluserquery1=$sqluserquery;
//         $sqluserquery1 .= "WHERE `email`='$id'";
// 		$db->sql($sqluserquery1);
// 		$result = $db->getResult();
		
// 		// print_r($result);
// 		if (!empty($result)) {
		    
// 		  $data = array(
// 				        'password'=> $password,
// 				        'otp'=> 'verified'
// 			            );
			            
// 			            $wherecl =  " `email` = '$id'";
//                 		$sql = $db->update('customer',$data,$wherecl);
//                 		$res = $db->getResult();
		    
// 		    $response['status'] = "true";
// 		    $response['message'] = "password changed successfully";
// 		    $response['data'] = $result;
			
			
// 		}else{
// 			$response['status'] = "false";
// 			$response['message'] = "No data found!";
// 		}
// 		echo json_encode($response);
// 	}
// }//////////  end of change password 




// Encrept Password
     function encryptpassword($key){
        return password_hash($key, 
          PASSWORD_DEFAULT);
    }
    
     // Encrept Password
     function decryptpassword($key){
        return password_hash($key, 
          PASSWORD_DEFAULT);
    }

 
 
    
    
?>